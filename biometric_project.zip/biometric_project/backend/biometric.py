def scan():
    with open('sample_fingerprint.bin', 'rb') as f:
        return f.read()
