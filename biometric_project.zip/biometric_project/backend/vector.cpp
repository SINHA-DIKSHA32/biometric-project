#include<iostream>
#include<vector>
int main(){
    vector<int> v;
    v.push_back(12);
    v.push_back(12);
    v.push_back(12);
    v.push_back(12);
    v.push_back(12);
    v.push_back(12);
    for(auto i : v){
        cout<<i<<" "<<endl;
    }
    return 0;
}